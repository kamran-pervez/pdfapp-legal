# EdifyPDF — LibreOfficeKit MPL modification package

Internal package used to fulfill written MPL source requests
(support.kklabs@gmail.com). Not published on the privacy/terms website.

Contains EdifyPDF modifications to Covered Software (`LibreOfficeKit.java`,
`fonts.conf`), diffs, and upstream references for Viewer 26.2.6.3 / VC131.

Upstream tree: F-Droid `org.documentfoundation.libreoffice_131_src.tar.gz`
and git tag `libreoffice-26.2.6.3`.
