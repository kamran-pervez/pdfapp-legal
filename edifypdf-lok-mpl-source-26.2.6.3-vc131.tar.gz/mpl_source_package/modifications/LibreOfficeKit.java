/* -*- Mode: Java; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */
/*
 * This file is part of the LibreOffice project.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *
 * EdifyPDF note: NativeLibLoader runs from init() (lazy) so class load does
 * not require natives until LibreOfficeKit.init() is called.
 * init(Context) is used from the :lok Service (Activity not required for paths).
 * Env matches Viewer: no Java putenv; sofficerc supplies HOME=$APP_DATA_DIR/cache.
 */

package org.libreoffice.kit;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.AssetManager;
import android.util.Log;

import java.io.File;
import java.nio.ByteBuffer;

public final class LibreOfficeKit
{
    private static String LOGTAG = LibreOfficeKit.class.getSimpleName();
    private static AssetManager mgr;

    private LibreOfficeKit() {
    }

    public static void initializeLibrary() {
    }

    private static native boolean initializeNative(String dataDir, String cacheDir, String apkFile, AssetManager mgr);

    public static native ByteBuffer getLibreOfficeKitHandle();

    public static native void putenv(String string);

    public static native void redirectStdio(boolean state);

    static boolean initializeDone = false;

    public static synchronized void init(Activity activity)
    {
        init((Context) activity);
    }

    /**
     * Initialize LOK using any Context (Application / Service). Matches Viewer
     * path wiring: dataDir, cacheDir, package APK path, AssetManager — no Java putenv.
     */
    public static synchronized void init(Context context)
    {
        if (initializeDone) {
            return;
        }

        Context app = context.getApplicationContext();
        NativeLibLoader.load();

        mgr = app.getResources().getAssets();

        ApplicationInfo applicationInfo = app.getApplicationInfo();
        String dataDir = applicationInfo.dataDir;
        String cacheDir = app.getCacheDir().getAbsolutePath();
        String apkFile = app.getPackageResourcePath();
        // sofficerc: HOME=$APP_DATA_DIR/cache — ensure directory exists before bootstrap.
        File homeDir = new File(dataDir, "cache");
        if (!homeDir.mkdirs() && !homeDir.isDirectory()) {
            Log.w(LOGTAG, "Failed to create HOME dir: " + homeDir.getAbsolutePath());
        }
        Log.i(LOGTAG, String.format(
            "Initializing LibreOfficeKit, dataDir=%s home=%s cacheDir=%s apk=%s\n",
            dataDir, homeDir.getAbsolutePath(), cacheDir, apkFile));

        // Viewer-identical: native bootstrap + sofficerc set APP_DATA_DIR/HOME.
        redirectStdio(true);

        if (!initializeNative(dataDir, cacheDir, apkFile, mgr)) {
            Log.e(LOGTAG, "Initialize native failed!");
            return;
        }
        initializeDone = true;
        Log.i(LOGTAG, "LibreOfficeKit: initializeNative ok");
    }

    public static boolean isInitializeDone() {
        return initializeDone;
    }
}

class NativeLibLoader {
        private static boolean done = false;

        protected static synchronized void load() {
            if (done)
                return;
            System.loadLibrary("nspr4");
            System.loadLibrary("plds4");
            System.loadLibrary("plc4");
            System.loadLibrary("nssutil3");
            System.loadLibrary("freebl3");
            System.loadLibrary("sqlite3");
            System.loadLibrary("softokn3");
            System.loadLibrary("nss3");
            System.loadLibrary("nssckbi");
            System.loadLibrary("nssdbm3");
            System.loadLibrary("smime3");
            System.loadLibrary("ssl3");

            System.loadLibrary("c++_shared");
            System.loadLibrary("lo-native-code");
            done = true;
        }
}
